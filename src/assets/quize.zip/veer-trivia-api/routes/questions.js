const express = require('express');
const router = express.Router();
const Question = require('../models/Question');

// 🔥 OPEN TRIVIA STYLE FORMAT — with filters & fix ✅
router.get('/formatted', async (req, res) => {
  try {
    const { amount = 10, category, difficulty } = req.query;

    const filter = {};
    if (category) filter.category = new RegExp(`^${category}$`, 'i'); // case-insensitive
    if (difficulty) filter.difficulty = new RegExp(`^${difficulty}$`, 'i');

    const questions = await Question.aggregate([
      { $match: filter },
      { $sample: { size: parseInt(amount) } }
    ]);

    const formatted = questions.map(q => {
      const correct_answer = q.options[q.correctOption];
      const incorrect_answers = q.options.filter((_, i) => i !== q.correctOption);
      return {
        question: q.question,
        correct_answer,
        incorrect_answers,
        category: q.category,
        difficulty: q.difficulty
      };
    });

    res.json({ response_code: 0, results: formatted });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// 📥 GET raw questions (filter supported)
router.get('/', async (req, res) => {
  try {
    const { amount = 10, category, difficulty } = req.query;

    const filter = {};
    if (category) filter.category = new RegExp(`^${category}$`, 'i');
    if (difficulty) filter.difficulty = new RegExp(`^${difficulty}$`, 'i');

    const questions = await Question.aggregate([
      { $match: filter },
      { $sample: { size: parseInt(amount) } }
    ]);

    res.json(questions);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ➕ Add new question
router.post('/', async (req, res) => {
  const question = new Question({
    question: req.body.question,
    options: req.body.options,
    correctOption: req.body.correctOption,
    category: req.body.category,
    difficulty: req.body.difficulty
  });

  try {
    const newQuestion = await question.save();
    res.status(201).json(newQuestion);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// 🛠️ Diagnostic route to get ALL questions
router.get('/all', async (req, res) => {
  try {
    const allQuestions = await Question.find();
    res.json(allQuestions);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
