const express = require('express');
const router = express.Router();
const Question = require('../models/Question');

// 📂 GET all unique categories (sorted + cleaned)
router.get('/', async (req, res) => {
  try {
    let categories = await Question.distinct('category');

    // Optional polish: trim + sort
    categories = categories.map(cat => cat.trim()).sort();

    res.status(200).json({
      success: true,
      count: categories.length,
      categories
    });
  } catch (err) {
    console.error("❌ Error fetching categories:", err);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

module.exports = router;
