require('dotenv').config();
const connectDB = require('../config/db');
const Question = require('../models/Question');
const questions = require('../data/questions.json');

const seedDatabase = async () => {
  await connectDB();
  
  try {
    await Question.deleteMany();
    await Question.insertMany(questions);
    console.log('Database seeded!');
    process.exit();
  } catch (err) {
    console.error('Seeding error:', err);
    process.exit(1);
  }
};

seedDatabase();