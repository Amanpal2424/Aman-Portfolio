const express = require('express');
const cors = require('cors'); // ⬅️ Yeh upar hona chahiye
require('dotenv').config();

const connectDB = require('./config/db');
const questionRoutes = require('./routes/questions');
const categoryRoutes = require('./routes/categories');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors()); // ✅ Yeh sabse upar lagao, WARNA kaam nahi karega

connectDB();

app.use(express.json());

app.use('/api/questions', questionRoutes);
app.use('/api/categories', categoryRoutes);

app.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
});
